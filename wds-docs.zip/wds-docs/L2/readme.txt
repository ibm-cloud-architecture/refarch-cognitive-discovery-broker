This folder contains files for working with Level 2 of the tutorial
The documents provided in this folder are owned by the respective owners as stated in those documents, and their copyright is duly acknowledged
The documents are collected from Internet search based on what is available to public as of June 2017
